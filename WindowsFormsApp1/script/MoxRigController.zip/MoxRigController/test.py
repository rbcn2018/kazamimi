
MoxRigController

import ri_rig_icons
ri_rig_icons.ri_rig_icons_menu()

import rr_main_curves
rr_main_curves.window_creation()

from Rigbox_Reborn_Curves_Tool import rr_main_curves
rr_main_curves.window_creation()
